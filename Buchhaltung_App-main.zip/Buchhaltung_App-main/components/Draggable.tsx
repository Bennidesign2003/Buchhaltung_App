import React from 'react'

type DraggableProps = {
  id: string
  children: React.ReactNode
  onDropItem?: (sourceId: string, targetId: string) => void
  onDragStartItem?: (id: string) => void
  onDragEnterItem?: (id: string) => void
  onDragEndItem?: () => void
  className?: string
}

export default function Draggable({
  id,
  children,
  onDropItem,
  onDragStartItem,
  onDragEnterItem,
  onDragEndItem,
  className = ''
}: DraggableProps) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', id)
    e.dataTransfer.effectAllowed = 'move'
    onDragStartItem && onDragStartItem(id)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
  }

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    // only notify parent when entering the wrapper itself, not its child elements
    if (e.currentTarget === e.target) {
      onDragEnterItem && onDragEnterItem(id)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const sourceId = e.dataTransfer.getData('text/plain')
    const targetId = id
    if (sourceId && sourceId !== targetId) onDropItem && onDropItem(sourceId, targetId)
    onDragEndItem && onDragEndItem()
  }

  const handleDragEnd = () => {
    onDragEndItem && onDragEndItem()
  }

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDrop={handleDrop}
      onDragEnd={handleDragEnd}
      className={`${className} cursor-move`}
      aria-grabbed="false"
    >
      {children}
    </div>
  )
}
