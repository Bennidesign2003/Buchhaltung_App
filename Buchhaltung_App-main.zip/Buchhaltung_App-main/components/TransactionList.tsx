'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { BanknotesIcon, DocumentTextIcon } from '@heroicons/react/24/outline'

type Invoice = {
  id: number
  customer: string
  amount: number
  totalAmount: number
  taxRate: number
  status: string
  createdAt: string
  dueDate?: string
}

type Expense = {
  id: number
  category: string
  amount: number
  date: string
  description?: string
  createdAt: string
}

type Item = (Invoice | Expense) & {
  type: 'invoice' | 'expense'
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, string> = {
    open: 'bg-yellow-100 text-yellow-700',
    paid: 'bg-green-100 text-green-700',
    overdue: 'bg-red-100 text-red-700'
  }
  const statusLabel: Record<string, string> = {
    open: 'Offen',
    paid: 'Bezahlt',
    overdue: 'Überfällig'
  }
  const klass = statusMap[status] || 'bg-gray-100 text-gray-700'
  return <span className={`px-2 py-1 text-xs rounded ${klass}`}>{statusLabel[status] || status}</span>
}

function CategoryBadge({ category }: { category: string }) {
  const categoryColors: Record<string, string> = {
    Material: 'bg-blue-100 text-blue-700',
    Personal: 'bg-purple-100 text-purple-700',
    Marketing: 'bg-pink-100 text-pink-700',
    Miete: 'bg-orange-100 text-orange-700',
    Nebenkosten: 'bg-cyan-100 text-cyan-700',
    Transport: 'bg-amber-100 text-amber-700',
    Software: 'bg-emerald-100 text-emerald-700',
    Bürobedarf: 'bg-indigo-100 text-indigo-700',
    Sonstiges: 'bg-gray-100 text-gray-700'
  }
  const klass = categoryColors[category] || 'bg-gray-100 text-gray-700'
  return <span className={`px-2 py-1 text-xs rounded ${klass}`}>{category}</span>
}

export default function TransactionList({ refreshTrigger }: { refreshTrigger?: number }) {
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [invoiceRes, expenseRes] = await Promise.all([
        fetch('/api/invoices'),
        fetch('/api/expenses')
      ])

      const invoices: Invoice[] = invoiceRes.ok ? await invoiceRes.json() : []
      const expenses: Expense[] = expenseRes.ok ? await expenseRes.json() : []

      // Convert to unified item format and merge
      const allItems: Item[] = [
        ...invoices.map((inv: Invoice) => ({ ...inv, type: 'invoice' as const })),
        ...expenses.map((exp: Expense) => ({
          ...exp,
          type: 'expense' as const,
          createdAt: exp.createdAt || exp.date
        }))
      ]

      // Sort by date descending (newest first)
      allItems.sort((a, b) => {
        const dateA = new Date(a.createdAt)
        const dateB = new Date(b.createdAt)
        return dateB.getTime() - dateA.getTime()
      })

      setItems(allItems)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [refreshTrigger])

  if (loading) {
    return (
      <div className="bg-white p-4 rounded shadow-sm">
        <div className="text-sm text-gray-500">Daten werden geladen...</div>
      </div>
    )
  }

  return (
    <div className="bg-white p-4 rounded shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-medium">Aktuelle Transaktionen</h3>
          <p className="text-sm text-gray-500">Rechnungen & Ausgaben auf einen Blick</p>
        </div>
        <div className="flex gap-2">
          <Link href="/invoices" className="text-sm text-blue-600 underline">
            Rechnungen
          </Link>
          <span className="text-gray-300">|</span>
          <Link href="/expenses" className="text-sm text-blue-600 underline">
            Ausgaben
          </Link>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-gray-500">Noch keine Transaktionen erstellt.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {items.slice(0, 8).map((item, idx) => (
            <li key={`${item.type}-${item.id}`} className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-3">
                <div className="text-2xl">
                  {item.type === 'invoice' ? <DocumentTextIcon className="w-5 h-5 text-blue-500" /> : <BanknotesIcon className="w-5 h-5 text-red-500" />}
                </div>
                <div>
                  <div className="font-medium">
                    {item.type === 'invoice' ? `#${item.id}` : `${(item as Expense).category}`}
                  </div>
                  <div className="text-sm text-gray-500">
                    {item.type === 'invoice' ? (item as Invoice).customer : (item as Expense).description}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium">€ {Number(item.type === 'invoice' ? (item as Invoice).totalAmount : item.amount).toFixed(2)}</div>
                <div className="mt-1">
                  {item.type === 'invoice' ? (
                    <StatusBadge status={(item as Invoice).status} />
                  ) : (
                    <CategoryBadge category={(item as Expense).category} />
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
