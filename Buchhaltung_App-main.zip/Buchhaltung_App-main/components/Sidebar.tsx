import Link from 'next/link'
import {
  HomeIcon,
  UsersIcon,
  TagIcon,
  DocumentTextIcon,
  CreditCardIcon,
  ChartPieIcon,
  BookOpenIcon
} from '@heroicons/react/24/outline'

const NavItem = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => (
  <Link href={href} className="flex items-center gap-3 px-4 py-2 rounded hover:bg-gray-100">
    <Icon className="w-5 h-5 text-gray-600" />
    <span className="ml-1">{label}</span>
  </Link>
)

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r h-screen sticky top-0">
      <div className="p-4 border-b">
        <div className="text-xl font-bold text-blue-600">FinTrack</div>
      </div>
      <nav className="p-2 mt-2">
        <NavItem href="/" icon={HomeIcon} label="Dashboard" />
        <NavItem href="/customers" icon={UsersIcon} label="Kunden" />
        <NavItem href="/suppliers" icon={TagIcon} label="Lieferanten" />
        <NavItem href="/invoices" icon={DocumentTextIcon} label="Rechnungen" />
        <NavItem href="/payments" icon={CreditCardIcon} label="Zahlungen" />
        <NavItem href="/reports" icon={ChartPieIcon} label="Berichte" />
        <NavItem href="/chart-of-accounts" icon={BookOpenIcon} label="Kontenplan" />
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <div className="flex items-center gap-3 px-3 py-2 rounded bg-gray-50">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">MM</div>
          <div>
            <div className="text-sm font-medium">Max Mustermann</div>
            <div className="text-xs text-gray-500">Administrator</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
