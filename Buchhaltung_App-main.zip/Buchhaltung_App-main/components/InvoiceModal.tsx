'use client'

import { useState } from 'react'
import { XMarkIcon } from '@heroicons/react/24/outline'

type InvoiceData = {
  customer: string
  amount: string
  taxRate: string
  dueDate: string
  description: string
}

export default function InvoiceModal({ isOpen, onClose, onSave }: { isOpen: boolean; onClose: () => void; onSave: (data: InvoiceData) => void }) {
  const [formData, setFormData] = useState<InvoiceData>({
    customer: '',
    amount: '',
    taxRate: '19',
    dueDate: '',
    description: ''
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.customer && formData.amount) {
      onSave(formData)
      setFormData({ customer: '', amount: '', taxRate: '19', dueDate: '', description: '' })
      onClose()
    }
  }

  if (!isOpen) return null

  const taxAmount = parseFloat(formData.amount || '0') * (parseFloat(formData.taxRate) / 100)
  const total = parseFloat(formData.amount || '0') + taxAmount

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full mx-4">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold">Neue Rechnung</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Kunde</label>
            <input
              type="text"
              name="customer"
              value={formData.customer}
              onChange={handleChange}
              placeholder="z.B. Müller GmbH"
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Betrag (€)</label>
            <input
              type="number"
              name="amount"
              value={formData.amount}
              onChange={handleChange}
              placeholder="0.00"
              step="0.01"
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Steuersatz (%)</label>
            <select
              name="taxRate"
              value={formData.taxRate}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="0">Keine Steuer</option>
              <option value="7">7%</option>
              <option value="19">19%</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Fälligkeitsdatum</label>
            <input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Beschreibung</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Rechnungsdetails..."
              rows={3}
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="bg-gray-50 p-3 rounded-md space-y-1">
            <div className="flex justify-between text-sm">
              <span>Nettobetrag:</span>
              <span>€ {parseFloat(formData.amount || '0').toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Steuern ({formData.taxRate}%):</span>
              <span>€ {taxAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-semibold text-base border-t pt-2 mt-2">
              <span>Gesamtbetrag:</span>
              <span>€ {total.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 border rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
              Abbrechen
            </button>
            <button type="submit" className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">
              Rechnung erstellen
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
