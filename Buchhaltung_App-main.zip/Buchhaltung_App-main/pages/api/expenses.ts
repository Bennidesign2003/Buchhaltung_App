import type { NextApiRequest, NextApiResponse } from 'next'
import { db } from '@/db'
import { expenses } from '@/db/schema'
import { eq } from 'drizzle-orm'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { category, amount, date, description } = req.body
      const parsedAmount = Number(amount)

      if (!category || Number.isNaN(parsedAmount)) {
        return res.status(400).json({ error: 'category und amount sind erforderlich' })
      }

      const result = await db
        .insert(expenses)
        .values({
          category,
          amount: parsedAmount,
          date: date || new Date().toISOString().split('T')[0],
          description: description || null
        })
        .run()

      // Fetch the created expense by using the last inserted rowid
      const created = await db
        .select()
        .from(expenses)
        .where(eq(expenses.id, result.lastInsertRowid as number))
        .get()

      const normalizedExpense = {
        ...created,
        amount: Number(created?.amount)
      }

      return res.status(201).json(normalizedExpense)
    } catch (error) {
      console.error('Error creating expense:', error)
      return res.status(500).json({ error: 'Fehler beim Erstellen der Ausgabe', details: String(error) })
    }
  } else if (req.method === 'GET') {
    try {
      const allExpenses = await db.select().from(expenses).all()
      const normalizedExpenses = allExpenses.map((exp: any) => ({
        ...exp,
        amount: Number(exp.amount)
      }))
      return res.status(200).json(normalizedExpenses)
    } catch (error) {
      console.error('Error fetching expenses:', error)
      return res.status(500).json({ error: 'Fehler beim Abrufen der Ausgaben', details: String(error) })
    }
  } else {
    return res.status(405).json({ error: 'Method not allowed' })
  }
}
