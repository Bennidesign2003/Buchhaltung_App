import type { NextApiRequest, NextApiResponse } from 'next'
import { db } from '@/db'
import { invoices } from '@/db/schema'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { customer, dueDate, description } = req.body
      const amount = Number(req.body.amount)
      const taxRate = Number(req.body.taxRate ?? 0)

      if (!customer || Number.isNaN(amount)) {
        return res.status(400).json({ error: 'customer und amount sind erforderlich' })
      }

      const taxAmount = +(amount * (taxRate / 100))
      const totalAmount = +(amount + taxAmount)

      const invoice = await db
        .insert(invoices)
        .values({
          customer,
          amount,
          taxRate,
          taxAmount,
          totalAmount,
          dueDate: dueDate || null,
          description: description || null,
          status: 'open'
        })
        .returning()

      const normalizedInvoice = {
        ...invoice[0],
        amount: Number(invoice[0]?.amount),
        taxRate: Number(invoice[0]?.taxRate),
        taxAmount: Number(invoice[0]?.taxAmount),
        totalAmount: Number(invoice[0]?.totalAmount)
      }

      return res.status(201).json(normalizedInvoice)
    } catch (error) {
      console.error('Error creating invoice:', error)
      return res.status(500).json({ error: 'Fehler beim Erstellen der Rechnung', details: String(error) })
    }
  } else if (req.method === 'GET') {
    try {
      const allInvoices = await db.select().from(invoices).all()
      const normalizedInvoices = allInvoices.map((inv: any) => ({
        ...inv,
        amount: Number(inv.amount),
        taxRate: Number(inv.taxRate),
        taxAmount: Number(inv.taxAmount),
        totalAmount: Number(inv.totalAmount)
      }))
      return res.status(200).json(normalizedInvoices)
    } catch (error) {
      console.error('Error fetching invoices:', error)
      return res.status(500).json({ error: 'Fehler beim Abrufen der Rechnungen', details: String(error) })
    }
  } else {
    return res.status(405).json({ error: 'Method not allowed' })
  }
}
