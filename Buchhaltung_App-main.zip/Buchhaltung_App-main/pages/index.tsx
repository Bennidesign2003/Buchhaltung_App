import { useEffect, useState } from 'react'
import Sidebar from '../components/Sidebar'
import Header from '../components/Header'
import DashboardCards from '../components/DashboardCards'
import LineChart from '../components/LineChart'
import ExpensesChart from '../components/ExpensesChart'
import ExpensesDistributionChart from '../components/ExpensesDistributionChart'
import TransactionList from '../components/TransactionList'
import QuickActions from '../components/QuickActions'
import InvoiceModal from '../components/InvoiceModal'
import CustomerModal from '../components/CustomerModal'
import ExpenseModal from '../components/ExpenseModal'
import Draggable from '../components/Draggable'

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false)
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const defaultOrder = ['chart', 'expenses-chart', 'invoices', 'expenses-dist', 'quick']
  // initialize with server-safe default; read saved order on client after mount to avoid hydration mismatch
  const [order, setOrder] = useState<string[]>(defaultOrder)

  useEffect(() => {
    try {
      const raw = localStorage.getItem('dashboardOrder')
      if (raw) setOrder(JSON.parse(raw))
    } catch (e) {
      // ignore
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem('dashboardOrder', JSON.stringify(order))
    } catch (e) {
      // ignore
    }
  }, [order])

  // move source before target (insert semantics) to avoid grid reflow issues
  const moveOrder = (sourceId: string, targetId: string) => {
    setOrder(prev => {
      const srcIdx = prev.indexOf(sourceId)
      const tgtIdx = prev.indexOf(targetId)
      if (srcIdx === -1 || tgtIdx === -1) return prev
      const next = prev.filter(k => k !== sourceId)
      // compute insertion index in the filtered array
      const insertAt = Math.max(0, next.indexOf(targetId))
      next.splice(insertAt, 0, sourceId)
      return next
    })
  }

  // drag state for visual placeholder behavior
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const [hoverTarget, setHoverTarget] = useState<string | null>(null)

  const handleDragStart = (id: string) => {
    setDraggingId(id)
    setHoverTarget(null)
  }

  const handleDragEnter = (id: string) => {
    if (id !== draggingId) setHoverTarget(id)
  }

  const handleDragEnd = () => {
    setDraggingId(null)
    setHoverTarget(null)
  }

  const handleDrop = (sourceId: string, targetId: string) => {
    // perform move (insert) on drop
    moveOrder(sourceId, targetId)
    // reset drag state
    setDraggingId(null)
    setHoverTarget(null)
  }

  const renderWidget = (key: string) => {
    if (key === 'chart') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className="lg:col-span-2"
        >
          <LineChart refreshKey={refreshKey} />
        </Draggable>
      )
    }

    if (key === 'expenses-chart') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className="lg:col-span-2"
        >
          <ExpensesChart refreshKey={refreshKey} />
        </Draggable>
      )
    }

    if (key === 'invoices') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className="lg:col-span-2"
        >
          <TransactionList refreshTrigger={refreshKey} />
        </Draggable>
      )
    }

    if (key === 'pie') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className=""
        >
          <PieChart />
        </Draggable>
      )
    }

    if (key === 'expenses-dist') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className=""
        >
          <ExpensesDistributionChart refreshKey={refreshKey} />
        </Draggable>
      )
    }

    if (key === 'quick') {
      return (
        <Draggable
          key={key}
          id={key}
          onDropItem={handleDrop}
          onDragStartItem={handleDragStart}
          onDragEnterItem={handleDragEnter}
          onDragEndItem={handleDragEnd}
          className=""
        >
            <QuickActions onNewInvoice={() => setIsModalOpen(true)} onNewCustomer={() => setIsCustomerModalOpen(true)} onNewExpense={() => setIsExpenseModalOpen(true)} />
        </Draggable>
      )
    }

    return null
  }

  const handleSaveInvoice = async (data: any) => {
    try {
      const response = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })

      if (response.ok) {
        const result = await response.json()
        alert(`Rechnung für ${data.customer} erstellt: €${data.amount}`)
        console.log('Rechnung gespeichert:', result)
        setRefreshKey(prev => prev + 1)
        setIsModalOpen(false)
      } else {
        alert('Fehler beim Speichern der Rechnung')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Speichern der Rechnung')
    }
  }

  const handleSaveCustomer = async (data: any) => {
    try {
      const response = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })

      if (response.ok) {
        const result = await response.json()
        alert(`Kunde "${data.name}" erstellt`)
        console.log('Kunde gespeichert:', result)
        setIsCustomerModalOpen(false)
      } else {
        const err = await response.json()
        alert(err.error || 'Fehler beim Speichern des Kunden')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Speichern des Kunden')
    }
  }

  const handleSaveExpense = async (data: any) => {
    try {
      const response = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })

      if (response.ok) {
        const result = await response.json()
        alert(`Ausgabe "${data.category}" erstellt: €${data.amount}`)
        console.log('Ausgabe gespeichert:', result)
        setRefreshKey(prev => prev + 1)
        setIsExpenseModalOpen(false)
      } else {
        alert('Fehler beim Speichern der Ausgabe')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Speichern der Ausgabe')
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 p-8">
        <Header onNewInvoice={() => setIsModalOpen(true)} />

        <div className="mt-6">
          <DashboardCards refreshTrigger={refreshKey} />
        </div>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {(() => {
            if (draggingId && hoverTarget) {
              const srcIdx = order.indexOf(draggingId)
              const tgtIdx = order.indexOf(hoverTarget)
              if (srcIdx !== -1 && tgtIdx !== -1) {
                // compute visual order with source removed and placeholder inserted at target position
                const vis = order.filter(k => k !== draggingId)
                const insertIdx = Math.max(0, vis.indexOf(hoverTarget))
                vis.splice(insertIdx, 0, 'PLACEHOLDER')
                
                return vis.map((k, idx) => {
                  if (k === 'PLACEHOLDER') {
                    // determine span class based on the item being replaced by placeholder
                    const spanClass = ['chart', 'expenses-chart', 'invoices'].includes(hoverTarget) ? 'lg:col-span-2' : ''
                    return (
                      <div key={`ph-${idx}`} className={spanClass}>
                        <div className="bg-gray-100 border border-dashed rounded h-40 flex items-center justify-center text-gray-400">Platzieren...</div>
                      </div>
                    )
                  }

                  return renderWidget(k)
                })
              }
            }

            return order.map(k => renderWidget(k))
          })()}
        </div>
      </div>

      <InvoiceModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveInvoice} />
      <CustomerModal isOpen={isCustomerModalOpen} onClose={() => setIsCustomerModalOpen(false)} onSave={handleSaveCustomer} />
      <ExpenseModal isOpen={isExpenseModalOpen} onClose={() => setIsExpenseModalOpen(false)} onSave={handleSaveExpense} />
    </div>
  )
}
