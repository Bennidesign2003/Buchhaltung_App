import { useEffect, useState } from 'react'
import Sidebar from '../components/Sidebar'
import Header from '../components/Header'
import SupplierModal from '../components/SupplierModal'
import { PencilIcon, TrashIcon } from '@heroicons/react/24/outline'

type Supplier = {
  id: number
  name: string
  email?: string
  phone?: string
  address?: string
  city?: string
  postalCode?: string
  country?: string
  taxId?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [loading, setLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  const loadSuppliers = async () => {
    try {
      const response = await fetch('/api/suppliers')
      if (response.ok) {
        const data = await response.json()
        setSuppliers(data)
      }
    } catch (error) {
      console.error('Error loading suppliers:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadSuppliers()
  }, [refreshKey])

  const handleSaveSupplier = async (data: any) => {
    try {
      const isEditing = editingSupplier?.id
      const method = isEditing ? 'PUT' : 'POST'
      const body = isEditing ? { ...data, id: editingSupplier.id } : data

      const response = await fetch('/api/suppliers', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      if (response.ok) {
        const result = await response.json()
        alert(`Lieferant "${data.name}" ${isEditing ? 'aktualisiert' : 'erstellt'}`)
        console.log('Supplier saved:', result)
        setRefreshKey(prev => prev + 1)
        closeModal()
      } else {
        const err = await response.json()
        alert(err.error || 'Fehler beim Speichern des Lieferanten')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Speichern des Lieferanten')
    }
  }

  const handleEdit = (supplier: Supplier) => {
    setEditingSupplier(supplier)
    setIsModalOpen(true)
  }

  const handleDelete = async (id: number) => {
    if (!confirm('Lieferant wirklich löschen?')) return

    try {
      const response = await fetch(`/api/suppliers?id=${id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        alert('Lieferant gelöscht')
        setRefreshKey(prev => prev + 1)
      } else {
        alert('Fehler beim Löschen des Lieferanten')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Löschen des Lieferanten')
    }
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setEditingSupplier(null)
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-8">
        <Header onNewInvoice={() => {}} />

        <div className="mt-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold">Lieferanten</h1>
              <p className="text-gray-600 mt-1">Verwalten Sie Ihre Lieferanten</p>
            </div>
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md font-medium hover:bg-blue-700"
            >
              + Neuer Lieferant
            </button>
          </div>

          <div className="bg-white rounded-lg shadow">
            {loading ? (
              <div className="p-6 text-center text-gray-500">Wird geladen...</div>
            ) : suppliers.length === 0 ? (
              <div className="p-6 text-center text-gray-500">Noch keine Lieferanten erfasst.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Email</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Telefon</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Stadt</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Land</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Steuernummer</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Aktionen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {suppliers.map(supplier => (
                      <tr key={supplier.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">{supplier.name}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{supplier.email || '-'}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{supplier.phone || '-'}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{supplier.city || '-'}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{supplier.country || '-'}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{supplier.taxId || '-'}</td>
                        <td className="px-6 py-4 text-sm">
                          <button
                            onClick={() => handleEdit(supplier)}
                            className="text-blue-600 hover:text-blue-800 mr-3"
                            title="Bearbeiten"
                          >
                            <PencilIcon className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(supplier.id)}
                            className="text-red-600 hover:text-red-800"
                            title="Löschen"
                          >
                            <TrashIcon className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      <SupplierModal isOpen={isModalOpen} onClose={closeModal} onSave={handleSaveSupplier} initialData={editingSupplier} />
    </div>
  )
}
