import { useEffect, useState } from 'react'
import Sidebar from '../components/Sidebar'
import Header from '../components/Header'
import CustomerModal from '../components/CustomerModal'
import { PencilIcon, TrashIcon } from '@heroicons/react/24/outline'

type Customer = {
  id: number
  name: string
  email: string | null
  phone: string | null
  address: string | null
  city: string | null
  postalCode: string | null
  country: string | null
  taxId: string | null
  notes: string | null
  createdAt: string
  updatedAt: string
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [loading, setLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  useEffect(() => {
    loadCustomers()
  }, [refreshKey])

  const loadCustomers = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/customers', { cache: 'no-store' })
      if (res.ok) {
        const data = await res.json()
        setCustomers(data)
      }
    } catch (e) {
      console.error('Error loading customers:', e)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveCustomer = async (data: any) => {
    try {
      const url = editingCustomer ? '/api/customers' : '/api/customers'
      const method = editingCustomer ? 'PUT' : 'POST'
      const payload = editingCustomer ? { ...data, id: editingCustomer.id } : data

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })

      if (response.ok) {
        alert(editingCustomer ? 'Kunde aktualisiert' : `Kunde "${data.name}" erstellt`)
        setIsModalOpen(false)
        setEditingCustomer(null)
        setRefreshKey(prev => prev + 1)
      } else {
        const err = await response.json()
        alert(err.error || 'Fehler beim Speichern des Kunden')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Fehler beim Speichern des Kunden')
    }
  }

  const handleDelete = async (id: number) => {
    if (confirm('Kunden wirklich löschen?')) {
      try {
        const res = await fetch(`/api/customers?id=${id}`, { method: 'DELETE' })
        if (res.ok) {
          alert('Kunde gelöscht')
          setRefreshKey(prev => prev + 1)
        } else {
          alert('Fehler beim Löschen')
        }
      } catch (e) {
        console.error('Error:', e)
        alert('Fehler beim Löschen')
      }
    }
  }

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setEditingCustomer(null)
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 p-8">
        <Header onNewInvoice={() => {}} />

        <div className="mt-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Kunden</h1>
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
            >
              + Neuer Kunde
            </button>
          </div>

          {loading ? (
            <div className="text-center py-8 text-gray-500">Lädt...</div>
          ) : customers.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <p className="text-gray-500 mb-4">Noch keine Kunden vorhanden</p>
              <button
                onClick={() => setIsModalOpen(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
              >
                Ersten Kunden erstellen
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">KUNDENNAME</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">E-MAIL</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">TELEFON</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">STADT</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">LAND</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">STEUERNUMMER</th>
                    <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">AKTIONEN</th>
                  </tr>
                </thead>
                <tbody>
                  {customers.map((customer, idx) => (
                    <tr key={customer.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{customer.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{customer.email || '–'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{customer.phone || '–'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{customer.city || '–'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{customer.country || '–'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{customer.taxId || '–'}</td>
                      <td className="px-6 py-4 text-right text-sm space-x-2">
                        <button
                          onClick={() => handleEdit(customer)}
                          className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
                        >
                          <PencilIcon className="w-4 h-4" />
                          Bearbeiten
                        </button>
                        <button
                          onClick={() => handleDelete(customer.id)}
                          className="text-red-600 hover:text-red-800 inline-flex items-center gap-1"
                        >
                          <TrashIcon className="w-4 h-4" />
                          Löschen
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <CustomerModal isOpen={isModalOpen} onClose={closeModal} onSave={handleSaveCustomer} initialData={editingCustomer} />
    </div>
  )
}
