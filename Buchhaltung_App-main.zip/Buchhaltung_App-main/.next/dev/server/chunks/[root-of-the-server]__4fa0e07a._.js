module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/react [external] (react, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react", () => require("react"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/better-sqlite3 [external] (better-sqlite3, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("better-sqlite3", () => require("better-sqlite3"));

module.exports = mod;
}),
"[externals]/drizzle-orm/better-sqlite3 [external] (drizzle-orm/better-sqlite3, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("drizzle-orm/better-sqlite3");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/drizzle-orm/sqlite-core [external] (drizzle-orm/sqlite-core, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("drizzle-orm/sqlite-core");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/drizzle-orm [external] (drizzle-orm, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("drizzle-orm");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/db/schema.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "invoices",
    ()=>invoices
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/drizzle-orm/sqlite-core [external] (drizzle-orm/sqlite-core, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm__$5b$external$5d$__$28$drizzle$2d$orm$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/drizzle-orm [external] (drizzle-orm, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm__$5b$external$5d$__$28$drizzle$2d$orm$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm__$5b$external$5d$__$28$drizzle$2d$orm$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
const invoices = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["sqliteTable"])('invoices', {
    id: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["integer"])('id').primaryKey({
        autoIncrement: true
    }),
    customer: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('customer').notNull(),
    amount: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["real"])('amount').notNull(),
    taxRate: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["real"])('tax_rate').notNull().default(19),
    taxAmount: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["real"])('tax_amount').notNull().default(0),
    totalAmount: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["real"])('total_amount').notNull(),
    dueDate: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('due_date'),
    description: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('description'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('created_at').default(__TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm__$5b$external$5d$__$28$drizzle$2d$orm$2c$__esm_import$29$__["sql"]`CURRENT_TIMESTAMP`).notNull(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('updated_at').default(__TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm__$5b$external$5d$__$28$drizzle$2d$orm$2c$__esm_import$29$__["sql"]`CURRENT_TIMESTAMP`).notNull(),
    status: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$sqlite$2d$core__$5b$external$5d$__$28$drizzle$2d$orm$2f$sqlite$2d$core$2c$__esm_import$29$__["text"])('status').default('open').notNull() // 'open', 'paid', 'overdue'
});
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/db/index.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/better-sqlite3 [external] (better-sqlite3, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$better$2d$sqlite3__$5b$external$5d$__$28$drizzle$2d$orm$2f$better$2d$sqlite3$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/drizzle-orm/better-sqlite3 [external] (drizzle-orm/better-sqlite3, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/db/schema.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$better$2d$sqlite3__$5b$external$5d$__$28$drizzle$2d$orm$2f$better$2d$sqlite3$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$better$2d$sqlite3__$5b$external$5d$__$28$drizzle$2d$orm$2f$better$2d$sqlite3$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
const sqlite = new __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__["default"]('buchhaltung.db');
const db = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$drizzle$2d$orm$2f$better$2d$sqlite3__$5b$external$5d$__$28$drizzle$2d$orm$2f$better$2d$sqlite3$2c$__esm_import$29$__["drizzle"])(sqlite, {
    schema: __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
});
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/pages/api/invoices.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$index$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/db/index.ts [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/db/schema.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$index$2e$ts__$5b$api$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$db$2f$index$2e$ts__$5b$api$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
async function POST(req) {
    try {
        const body = await req.json();
        const { customer, amount, taxRate, dueDate, description } = body;
        if (!customer || amount === undefined) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'customer und amount sind erforderlich'
            }, {
                status: 400
            });
        }
        const taxAmount = amount * (taxRate / 100);
        const totalAmount = amount + taxAmount;
        const invoice = await __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$index$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["db"].insert(__TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["invoices"]).values({
            customer,
            amount,
            taxRate,
            taxAmount,
            totalAmount,
            dueDate: dueDate || null,
            description: description || null,
            status: 'open'
        }).returning();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__["NextResponse"].json(invoice[0], {
            status: 201
        });
    } catch (error) {
        console.error('Error creating invoice:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Fehler beim Erstellen der Rechnung'
        }, {
            status: 500
        });
    }
}
async function GET(req) {
    try {
        const allInvoices = await __TURBOPACK__imported__module__$5b$project$5d2f$db$2f$index$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["db"].select().from(__TURBOPACK__imported__module__$5b$project$5d2f$db$2f$schema$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["invoices"]).all();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__["NextResponse"].json(allInvoices);
    } catch (error) {
        console.error('Error fetching invoices:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$api$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Fehler beim Abrufen der Rechnungen'
        }, {
            status: 500
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4fa0e07a._.js.map