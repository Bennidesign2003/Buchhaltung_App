var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/customers.js")
R.c("server/chunks/node_modules_next_dist_a6513d2d._.js")
R.c("server/chunks/[root-of-the-server]__e30f6f89._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/customers.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/customers.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
