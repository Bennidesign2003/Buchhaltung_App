var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/expenses-distribution.js")
R.c("server/chunks/node_modules_next_dist_6262dabc._.js")
R.c("server/chunks/[root-of-the-server]__2dd901ec._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/expenses-distribution.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/expenses-distribution.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
