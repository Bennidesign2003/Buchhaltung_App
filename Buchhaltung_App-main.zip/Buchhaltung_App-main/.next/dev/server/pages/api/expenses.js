var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/expenses.js")
R.c("server/chunks/node_modules_next_dist_ad071f8c._.js")
R.c("server/chunks/[root-of-the-server]__48f8c39a._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/expenses.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/expenses.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
