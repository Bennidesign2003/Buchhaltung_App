var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/invoices.js")
R.c("server/chunks/node_modules_next_dist_cf1b8c96._.js")
R.c("server/chunks/[root-of-the-server]__903e7b30._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/invoices.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/invoices.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
