__turbopack_load_page_chunks__("/customers", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_4025f6b7._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_next_link_207af988.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_76b414ce._.js",
  "static/chunks/[root-of-the-server]__d04c9bf1._.js",
  "static/chunks/pages_customers_2da965e7._.js",
  "static/chunks/turbopack-pages_customers_d80197b1._.js"
])
